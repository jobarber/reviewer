def test_github_connected():
    assert True
